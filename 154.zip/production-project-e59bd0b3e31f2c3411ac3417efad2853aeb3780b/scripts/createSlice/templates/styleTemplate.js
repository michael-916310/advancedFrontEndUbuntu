module.exports = (componentName) => `.${componentName} {

}`;
