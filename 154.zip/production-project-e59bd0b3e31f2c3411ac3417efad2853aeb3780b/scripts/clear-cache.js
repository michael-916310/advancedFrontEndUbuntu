// path/fs
console.log('CLEAR CACHE');
