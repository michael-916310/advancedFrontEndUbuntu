export function selectByTestId(testId: string) {
    return `[data-testid="${testId}"]`;
}
