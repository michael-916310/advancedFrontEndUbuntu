// Форма создания статьи
export interface ArticleEditFormSchema {
    id: string;
}
