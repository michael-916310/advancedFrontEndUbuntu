import { AdminPanelPageAsync } from './ui/AdminPanelPage.async';

export { AdminPanelPageAsync as AdminPanelPage };
