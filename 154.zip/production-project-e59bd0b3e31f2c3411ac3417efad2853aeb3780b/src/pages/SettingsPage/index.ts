export { SettingsPageAsync as SettingsPage } from './ui/SettingsPage/SettingsPage.async';
