export interface FeatureFlags {
    isArticleRatingEnabled?: boolean;
    isCounterEnabled?: boolean;
    isAppRedesigned?: boolean;
}
