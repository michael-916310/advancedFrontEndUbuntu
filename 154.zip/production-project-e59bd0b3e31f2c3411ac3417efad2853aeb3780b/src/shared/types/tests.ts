export interface TestProps {
    'data-testid'?: string;
}
