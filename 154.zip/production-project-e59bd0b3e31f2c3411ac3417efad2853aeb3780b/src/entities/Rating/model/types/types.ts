export interface Rating {
    rate: number;
    feedback?: string;
}
